Thor R38.2.1 本机刷写工具修正：便携文本补丁

适用对象：本次 NVIDIA R38.2.1 BSP 的 unified_flash Python 主机工具。
这些是 Windows + WSL + Windows 原生 ADB 的本机兼容适配，不是通用 Thor 必须安装的固件补丁，不修改板上安全策略、签名验证或 EEPROM 内容。

文件：
01-native-adb-routing.patch
  修改 unified_flash/tools/flashtools/bootburn_t264_py/bootburn_adb.py。
  由轮02 source-bootburn_adb.py 备份与当前已验证源码生成。
  检测 adb.windows-native 标记后，将“Linux lsusb 是否看到 NVIDIA”改为针对目标序列号的 adb get-state；Windows ADB 接口本来就应留在 Windows，不能拿 WSL lsusb 当就绪条件。
  Windows 管理 ADB server 时，RestartAdbServer 改为 reconnect offline，避免 WSL 客户端杀掉或拉起另一份 server；原生 Linux、无 marker 时保留原分支。

02-recovery-wait.patch
  修改 unified_flash/tools/flashtools/bootburn_t264_py/bootburn_lib.py。
  由轮03 recovery-wait-backup/source-bootburn_lib.py 备份与当前已验证源码生成。
  APX/RCM 重枚举的就绪检查等待30秒，读取同一个目标 portPath 的 busnum/devnum，要求为正整数且对应 /dev/bus/usb 节点已存在；保留之后的 udev 路径核对并扩展其等待。不能写成“禁用 USB 校验”。

  含两个基线 SHA256、当前源码 SHA256、补丁 SHA256，以及 dry-run 结果。
  本轮在独立工作区副本上执行 patch --dry-run -p1，两个补丁均退出0；没有对 BSP 应用补丁。
  当前 BSP 源码与 out/bsp_images/tools 中对应的两份生成副本逐字节相同。

不包含：
- 原始大二进制、NVIDIA BSP、ADB 可执行文件。
- adb 的 Windows 调用适配器、Windows helper、可执行位补偿逻辑；这几项必须配合主文档附带的独立脚本部署。
- EEPROM 修复；它是同步本板厂商 BCT 配置，属于另一项修复。
- 设备序列号、Windows路径、端口等改写。补丁本身没有硬编码本机目录，适配器/helper 仍需按实际环境检查配置。

应用目录和版本核对：
补丁路径 a/ 与 b/ 后面均相对于 Linux_for_Tegra 根目录，应从该目录使用 -p1。
请先备份要改的两个文本文件，并对照 DEPLOY.txt 第二节的原始基线哈希。现有已适配 BSP 按第六节核对文件一致性，无需重复应用。
版本或内容不同，先检查差异；不要用模糊/强制方式自动覆盖。

示例，假定附件放在 /path/to/thor-manual-patches：
cd /path/to/Linux_for_Tegra
sha256sum unified_flash/tools/flashtools/bootburn_t264_py/bootburn_adb.py
sha256sum unified_flash/tools/flashtools/bootburn_t264_py/bootburn_lib.py
patch --dry-run -p1 < /path/to/thor-manual-patches/01-native-adb-routing.patch
patch --dry-run -p1 < /path/to/thor-manual-patches/02-recovery-wait.patch

只有版本和 dry-run 均通过、且已准备配套适配器/helper 时，才执行实际应用：
patch -p1 < /path/to/thor-manual-patches/01-native-adb-routing.patch
patch -p1 < /path/to/thor-manual-patches/02-recovery-wait.patch

之后应执行主文档的 --no-flash 生成阶段，工具源会进入新生成包；再比较源与生成工具内容一致：
cmp unified_flash/tools/flashtools/bootburn_t264_py/bootburn_adb.py unified_flash/out/bsp_images/tools/flashtools/bootburn_t264_py/bootburn_adb.py
cmp unified_flash/tools/flashtools/bootburn_t264_py/bootburn_lib.py unified_flash/out/bsp_images/tools/flashtools/bootburn_t264_py/bootburn_lib.py

不要只改 source 后直接 --flash-only 使用旧 generated 工具，也不要只改 generated 后在下次生成时丢失修正。本次已经完整同步两处；上述步骤供从匹配基线复现使用。

证据依据：
WSL USBIP 10MiB push 多种 ADB/强制绑定配置均超时，同设备 Windows 原生 ADB 传输成功并 MD5 一致；本次主流程改走 Windows 后完成刷写。
轮03记录 RCM 重枚举窗口内设备节点未准备就绪的失败，等待逻辑修正后后续运行通过该阶段。
没有据此认定 USBIP 具体内核 bug、过滤驱动或线缆是唯一底层根因。
