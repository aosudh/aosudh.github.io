param([string]$OutputDir)
$ErrorActionPreference = 'Stop'
$serialPort = New-Object System.IO.Ports.SerialPort
$serialPort.PortName = 'COM4'
$serialPort.BaudRate = 115200
$serialPort.Parity = [System.IO.Ports.Parity]::None
$serialPort.DataBits = 8
$serialPort.StopBits = [System.IO.Ports.StopBits]::One
$serialPort.Handshake = [System.IO.Ports.Handshake]::None
$serialPort.DtrEnable = $false
$serialPort.RtsEnable = $false
$serialPort.ReadTimeout = 1000
$rawStream = $null
$textWriter = $null
try {
    [System.IO.Directory]::CreateDirectory($OutputDir) | Out-Null
    $serialPort.Open()
    $rawStream = [System.IO.File]::Open((Join-Path $OutputDir 'serial.bin'), [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::Write, [System.IO.FileShare]::Read)
    $textWriter = New-Object System.IO.StreamWriter((Join-Path $OutputDir 'serial.log'), $false, (New-Object System.Text.UTF8Encoding($false)))
    $textWriter.AutoFlush = $true
    $decoder = [System.Text.Encoding]::UTF8.GetDecoder()
    $byteBuffer = New-Object byte[] 16384
    $charBuffer = New-Object char[] 16384
    $captureStart = [DateTimeOffset]::Now
    $nextReport = [DateTime]::UtcNow.AddSeconds(10)
    $totalBytes = 0L
    Write-Output ('SERIAL_READY COM4 115200 8N1 no-flow PID=' + $PID + ' at ' + $captureStart.ToString('o'))
    [System.IO.File]::WriteAllText((Join-Path $OutputDir 'serial-ready.txt'), $captureStart.ToString('o'))
    while (-not (Test-Path -LiteralPath (Join-Path $OutputDir 'stop-capture.flag'))) {
        if (([DateTimeOffset]::Now - $captureStart).TotalMinutes -gt 45) { break }
        $availableBytes = $serialPort.BytesToRead
        if ($availableBytes -gt 0) {
            $readCount = $serialPort.Read($byteBuffer, 0, [Math]::Min($availableBytes, $byteBuffer.Length))
            $rawStream.Write($byteBuffer, 0, $readCount)
            $rawStream.Flush()
            $charCount = $decoder.GetChars($byteBuffer, 0, $readCount, $charBuffer, 0)
            $textWriter.Write($charBuffer, 0, $charCount)
            $totalBytes += $readCount
        } else { Start-Sleep -Milliseconds 50 }
        if ([DateTime]::UtcNow -ge $nextReport) {
            Write-Output ('SERIAL_CAPTURE bytes=' + $totalBytes + ' at ' + [DateTimeOffset]::Now.ToString('o'))
            $nextReport = [DateTime]::UtcNow.AddSeconds(10)
        }
    }
    Write-Output ('SERIAL_FINISHED bytes=' + $totalBytes)
} finally {
    if ($textWriter) { $textWriter.Dispose() }
    if ($rawStream) { $rawStream.Dispose() }
    if ($serialPort.IsOpen) { $serialPort.Close() }
    $serialPort.Dispose()
}
