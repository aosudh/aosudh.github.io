#!/usr/bin/env python3
"""Thor diagnostic adapter: keep RCM in WSL, use native Windows USB for ADB."""
import os
from pathlib import Path
import shutil
import shlex
import signal
import stat
import subprocess
import sys
import tempfile
import time

ROOT = Path('/mnt/c/ThorFlash/work')
EXE = str(ROOT / 'windows-adb/platform-tools/adb.exe')
STAGE = ROOT / 'adb-stage'
# An explicit server host prevents clients launched through WSL interop from
# spawning a competing Windows USB server. The Windows launcher owns it.
PREFIX = [EXE, '-H', '127.0.0.1', '-P', '15037']
child = None

def stop(signum, frame):
    if child is not None and child.poll() is None:
        child.terminate()
    raise SystemExit(128 + signum)

signal.signal(signal.SIGTERM, stop)
signal.signal(signal.SIGINT, stop)

def invoke(args, quiet=False):
    global child
    child = subprocess.Popen(PREFIX + args,
                             stdout=subprocess.DEVNULL if quiet else None,
                             stderr=subprocess.DEVNULL if quiet else None)
    return child.wait()

def winpath(p):
    return subprocess.check_output(['wslpath', '-w', str(p)], text=True).strip()

def main():
    args = sys.argv[1:]
    i = 0
    while i < len(args) and args[i].startswith('-'):
        if args[i] in ('-s', '-t'):
            i += 2
        elif args[i] in ('-d', '-e', '-a'):
            i += 1
        else:
            raise ValueError('Unsupported ADB global option: ' + args[i])
    if i == len(args):
        return invoke(args)
    command = args[i]
    if command == 'wait-for-device':
        # The vendor wraps this in Linux timeout(5). Avoid leaving a Windows
        # wait-for-device client alive after that Linux process is terminated.
        while invoke(args[:i] + ['get-state'], quiet=True) != 0:
            time.sleep(0.3)
        return 0
    if command not in ('push', 'pull'):
        return invoke(args)
    STAGE.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='thor-adb-', dir=STAGE) as td:
        staging = Path(td)
        if command == 'push':
            if len(args[i + 1:]) != 2 or args[i + 1].startswith('-'):
                raise ValueError('Expected vendor ADB push SOURCE DESTINATION')
            source = Path(args[i + 1]).absolute()
            if not source.is_file():
                raise ValueError('ADB push source is not a regular file')
            staged = staging / source.name
            mode = stat.S_IMODE(source.stat().st_mode) & 0o777
            remote = args[i + 2]
            shutil.copyfile(source, staged)
            args[i + 1] = winpath(staged)
            code = invoke(args)
            if code != 0:
                return code
            # Windows adb cannot derive Linux executable bits from NTFS.
            # Restore the source permission bits directly, before a newly
            # transferred wrapper is used to run the vendor's own chmod.
            remote_file = remote.rstrip('/') + '/' + source.name
            fix_mode = (
                'if [ -d ' + shlex.quote(remote) + ' ]; then chmod '
                + format(mode, 'o') + ' ' + shlex.quote(remote_file)
                + '; else chmod ' + format(mode, 'o') + ' '
                + shlex.quote(remote) + '; fi'
            )
            return invoke(args[:i] + ['shell', fix_mode])
        if len(args[i + 1:]) != 2:
            raise ValueError('Expected vendor ADB pull SOURCE DESTINATION')
        destination = Path(args[i + 2]).absolute()
        if not destination.is_dir():
            raise ValueError('Vendor ADB pull destination must be an existing directory')
        args[i + 2] = winpath(staging)
        code = invoke(args)
        if code == 0:
            for item in staging.iterdir():
                if item.is_dir():
                    shutil.copytree(item, destination / item.name, dirs_exist_ok=True)
                else:
                    shutil.copyfile(item, destination / item.name)
        return code

if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError) as e:
        print('Thor Windows ADB adapter: ' + str(e), file=sys.stderr)
        raise SystemExit(1)
