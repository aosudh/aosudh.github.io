import datetime
import pathlib
import subprocess
import sys
import time

out = pathlib.Path(sys.argv[1])
if not (out / 'serial-ready.txt').exists():
    raise SystemExit('Serial capture is not ready; refusing to start flashing without it.')
cmd = ['wsl.exe', '-d', 'Ubuntu-22.04', '-u', 'root', '--cd', '/home/USER/thor-flash/test/Linux_for_Tegra', '--exec', '/bin/bash', './l4t_initrd_flash.sh', 'ces-agx-thor-p3834-0008-jat-001-nvme', 'internal']
if len(sys.argv) > 2:
    assert sys.argv[2] == '--flash-only'
    cmd.insert(-2, '--flash-only')
stamp = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()
with (out / 'flash.log').open('xb') as log:
    start = f'START {stamp}\nCOMMAND {cmd!r}\n'
    log.write(start.encode('utf-8'))
    log.flush()
    print(start, flush=True)
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, bufsize=0)
    (out / 'flash-process.txt').write_text(str(proc.pid), encoding='ascii')
    last_report = time.monotonic()
    total_bytes = 0
    while True:
        chunk = proc.stdout.read(16384)
        if not chunk:
            break
        log.write(chunk)
        log.flush()
        total_bytes += len(chunk)
        if time.monotonic() - last_report >= 30:
            print(f'FLASH_CAPTURE bytes={total_bytes}; details in {out / "flash.log"}', flush=True)
            last_report = time.monotonic()
    code = proc.wait()
    end = f'\nEND {datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()} EXIT_CODE={code}\n'
    log.write(end.encode('utf-8'))
    (out / 'flash-exit-code.txt').write_text(str(code), encoding='ascii')
    print(end, flush=True)
    raise SystemExit(code)
