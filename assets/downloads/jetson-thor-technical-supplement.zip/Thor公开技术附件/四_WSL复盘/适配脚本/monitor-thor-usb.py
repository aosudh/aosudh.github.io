import datetime
import pathlib
import subprocess
import sys
import time

out = pathlib.Path(sys.argv[1])
tool = r'C:\Program Files\usbipd-win\usbipd.exe'
stop = out / 'stop-capture.flag'
last = None
started = time.monotonic()
with (out / 'usb-events.log').open('x', encoding='utf-8', buffering=1) as log:
    while not stop.exists() and time.monotonic() - started < 2700:
        p = subprocess.run([tool, 'list'], capture_output=True, timeout=15)
        text = p.stdout.decode('utf-8', errors='replace')
        error = p.stderr.decode('utf-8', errors='replace')
        state = (p.returncode, text, error)
        if state != last:
            stamp = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()
            entry = f'\n[{stamp}] exit={p.returncode}\n{text}{error}'
            log.write(entry)
            print(entry, flush=True)
            last = state
        time.sleep(1)
