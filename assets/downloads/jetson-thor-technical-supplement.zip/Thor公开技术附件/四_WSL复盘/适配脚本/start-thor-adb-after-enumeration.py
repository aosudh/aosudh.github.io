"""Run on Windows: start the dedicated ADB server after initrd USB appears."""
import datetime
import os
from pathlib import Path
import subprocess
import sys
import time

out = Path(sys.argv[1])
root = Path(__file__).resolve().parent
adb = str(root / 'windows-adb/platform-tools/adb.exe')
usbipd = r'C:\Program Files\usbipd-win\usbipd.exe'
prefix = [adb, '-H', '127.0.0.1', '-P', '15037']
serial = 'THOR_SERIAL'
flags = subprocess.CREATE_NO_WINDOW
with (out / 'adb-host-launch.log').open('x', encoding='utf-8', buffering=1) as log:
    def report(message):
        line = datetime.datetime.now().astimezone().isoformat() + ' ' + message
        log.write(line + '\n')
        print(line, flush=True)
    report('Waiting for Thor FunctionFS 0955:7100 on bus 2-1, native Windows ownership.')
    deadline = time.monotonic() + 180
    while time.monotonic() < deadline:
        listing = subprocess.run([usbipd, 'list'], capture_output=True, timeout=10, creationflags=flags).stdout.decode('utf-8', 'replace')
        target_lines = [line for line in listing.splitlines() if line.lstrip().startswith('2-1') and '0955:7100' in line]
        if target_lines:
            assert 'Not shared' in target_lines[0], 'ADB function must remain owned by Windows'
            report(target_lines[0])
            break
        time.sleep(0.5)
    else:
        raise SystemExit('Timed out waiting for Thor initrd USB; no server started.')
    # This port belongs only to this task. The WSL shim uses -H and cannot
    # auto-spawn a replacement while this host restarts the server.
    stopped = subprocess.run(prefix + ['kill-server'], capture_output=True, timeout=10, creationflags=flags)
    report('Dedicated previous server stop return=' + str(stopped.returncode))
    env = os.environ.copy()
    env['ADB_TRACE'] = 'usb,transport'
    with (out / 'adb-server-stdout.log').open('wb') as stdout, (out / 'adb-server-trace.log').open('wb') as stderr:
        server = subprocess.Popen([adb, '-P', '15037', 'nodaemon', 'server'], stdin=subprocess.DEVNULL,
                                  stdout=stdout, stderr=stderr, env=env, creationflags=flags)
    (out / 'adb-server-pid.txt').write_text(str(server.pid))
    report('Started native Windows ADB server PID=' + str(server.pid))
    deadline = time.monotonic() + 25
    while time.monotonic() < deadline:
        result = subprocess.run(prefix + ['-s', serial, 'get-state'], capture_output=True, timeout=5, creationflags=flags)
        if result.returncode == 0 and result.stdout.strip() == b'device':
            report('THOR_ADB_READY ' + serial)
            raise SystemExit(0)
        if server.poll() is not None:
            raise SystemExit('Native server exited: ' + str(server.returncode))
        time.sleep(0.5)
    raise SystemExit('Native server did not enumerate Thor within 25 seconds; see adb-server-trace.log.')
